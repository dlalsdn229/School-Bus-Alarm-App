package com.example.user.sbus;

import android.content.Intent;
import android.os.Handler;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class Offterm1 extends AppCompatActivity {

    TextView mCurTimeTextView;
    TimerTask MainTimerTask;
    Timer mTimer;

    private ListView dataListView;
    private DatalistAdapter adapter;
    private List<Data> DataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offterm1);

        //현재시각 표시
        Date rightNow = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("kk:mm:ss");
        String dateString = formatter.format(rightNow);

        //새로고침 정보
        TextView refreshinfo = (TextView) findViewById(R.id.refreshinfo);
        refreshinfo.setText(dateString + "에 갱신 됨.");

        //현재시간 핸들러
        mCurTimeTextView = (TextView) findViewById(R.id.CurrentTimeView);
        MainTimerTask timerTask = new MainTimerTask();
        mTimer = new Timer();
        mTimer.schedule(timerTask, 500, 1000);

        //버튼,리스트 등 화면구성
        Button refreshbtn = (Button) findViewById(R.id.refreshbtn);
        Button homeButton = (Button) findViewById(R.id.homeButton);
        final Button noticeButton = (Button) findViewById(R.id.noticeButton);
        final Button alarmButton = (Button) findViewById(R.id.alarmButton);
        final Button wholettButton = (Button) findViewById(R.id.wholettButton);
        final LinearLayout mainScreen = (LinearLayout) findViewById(R.id.mainscreen);
        dataListView = (ListView) findViewById(R.id.DataListView);
        DataList = new ArrayList<Data>();
        adapter = new DatalistAdapter(getApplicationContext(), DataList);
        dataListView.setAdapter(adapter);

        //임시 리스트 값
        DataList.add(new Data("11:11:11","11:11:11","11:11:11"));
        DataList.add(new Data("11:11:11","11:11:11","11:11:11"));
        DataList.add(new Data("11:11:11","11:11:11","11:11:11"));
        DataList.add(new Data("11:11:11","11:11:11","11:11:11"));
        DataList.add(new Data("11:11:11","11:11:11","11:11:11"));
        DataList.add(new Data("11:11:11","11:11:11","11:11:11"));



        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               onRestart();
            }
        });

        //버튼 리스너
        noticeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mainScreen.setVisibility(View.GONE);
                noticeButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                alarmButton.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                wholettButton.setBackgroundColor(getResources().getColor(R.color.colorAccent));


                /****/
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment, new NoticeFragment());
                fragmentTransaction.commit();
                /****/

            }
        });

        alarmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mainScreen.setVisibility(View.GONE);
                noticeButton.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                alarmButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                wholettButton.setBackgroundColor(getResources().getColor(R.color.colorAccent));


                /****/
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment, new AlarmFrament());
                fragmentTransaction.commit();

                 /****/
            }
        });

        wholettButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mainScreen.setVisibility(View.GONE);
                noticeButton.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                alarmButton.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                wholettButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));


                /****/
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment, new WholeTTableFragment());
                fragmentTransaction.commit();
                /** **/
            }
        });

        refreshbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onRestart();
            }
        });

    }

    @Override
    protected void onDestroy() {
        mTimer.cancel();
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        //mTimer.cancel();
        super.onPause();
    }

    @Override
    protected void onResume() {
        MainTimerTask timerTask = new MainTimerTask();
        mTimer.schedule(timerTask, 500, 3000);
        super.onResume();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Intent intent = new Intent(Offterm1.this, Offterm1.class );
        startActivity(intent);
        finish();
    }

    private Handler mHandler = new Handler();
    private Runnable mUpdateTimeTask = new Runnable() {
        public void run() {
            Date rightNow = new Date();
            SimpleDateFormat formatter = new SimpleDateFormat("kk:mm:ss");
            String dateString = formatter.format(rightNow);
            mCurTimeTextView.setText(dateString);

        }
    };

    class MainTimerTask extends TimerTask {
        public void run() {
            mHandler.post(mUpdateTimeTask);
        }
    }


}
