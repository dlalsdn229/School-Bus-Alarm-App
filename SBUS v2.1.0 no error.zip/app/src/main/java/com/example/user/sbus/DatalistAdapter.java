package com.example.user.sbus;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class DatalistAdapter extends BaseAdapter{

    private Context context;
    private List<Data> dataList;

    public DatalistAdapter(Context context, List<Data> dataList) {
        this.context = context;
        this.dataList = dataList;
    }

    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public Object getItem(int i) {
        return dataList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        View v = View.inflate(context, R.layout.timeview, null);
        TextView TrainTText = (TextView) v.findViewById(R.id.TrainTText);
        TextView BusTText = (TextView) v.findViewById(R.id.BusTText);
        TextView RemainTText = (TextView) v.findViewById(R.id.RemainTText);

        TrainTText.setText(dataList.get(i).getBusTime());
        BusTText.setText(dataList.get(i).getTrainTime());
        RemainTText.setText(dataList.get(i).getRemainTime());

        v.setTag(dataList.get(i).getBusTime());

        return v;
    }
}
