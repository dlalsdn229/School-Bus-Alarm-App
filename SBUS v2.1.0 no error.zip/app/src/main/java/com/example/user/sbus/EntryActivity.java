package com.example.user.sbus;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioButton;

public class EntryActivity extends AppCompatActivity {

    private BackPressCloseHandler backPressCloseHandler;
    private int flag = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entry);

        final Button schtoston = (Button) findViewById(R.id.schtoston);
        final Button sttoschon = (Button) findViewById(R.id.sttoschon);
        final Button schtostoff = (Button) findViewById(R.id.schtostoff);
        final Button sttoschoff = (Button) findViewById(R.id.sttoschoff);
        final RadioButton radioButton1 = (RadioButton) findViewById(R.id.onterm);
        final RadioButton radioButton2 = (RadioButton) findViewById(R.id.offterm);

        backPressCloseHandler = new BackPressCloseHandler(this);
        //entry 화면 버튼 리스너
        schtoston.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EntryActivity.this, Onterm1.class);
                EntryActivity.this.startActivity(intent);
            }
        });

        sttoschon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EntryActivity.this, Onterm2.class);
                EntryActivity.this.startActivity(intent);
            }
        });

        schtostoff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EntryActivity.this, Offterm1.class);
                EntryActivity.this.startActivity(intent);
            }
        });

        sttoschoff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EntryActivity.this, Offterm2.class);
                EntryActivity.this.startActivity(intent);
            }
        });

        //라디오버튼 눌렀을때 버튼전환, 객체숨김처리
        radioButton1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                schtoston.setVisibility(View.GONE);
                sttoschon.setVisibility(View.GONE);
                schtostoff.setVisibility(View.VISIBLE);
                sttoschoff.setVisibility(View.VISIBLE);
            }
        });

        radioButton2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                schtostoff.setVisibility(View.GONE);
                sttoschoff.setVisibility(View.GONE);
                schtoston.setVisibility(View.VISIBLE);
                sttoschon.setVisibility(View.VISIBLE);
            }
        });
        //----------
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        backPressCloseHandler.onBackPressed();
    }
}

