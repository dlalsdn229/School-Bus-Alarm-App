package com.example.user.sbus;

public class Data {

    String TrainTime,BusTime,RemainTime;

    public Data(String trainTime, String busTime, String remainTime) {
        TrainTime = trainTime;
        BusTime = busTime;
        RemainTime = remainTime;
    }

    public String getTrainTime() {
        return TrainTime;
    }

    public void setTrainTime(String trainTime) {
        this.TrainTime = trainTime;
    }

    public String getBusTime() {
        return BusTime;
    }

    public void setBusTime(String busTime) {
        this.BusTime = busTime;
    }

    public String getRemainTime() {
        return RemainTime;
    }

    public void setRemainTime(String remainTime) {
        this.RemainTime = remainTime;
    }
}
