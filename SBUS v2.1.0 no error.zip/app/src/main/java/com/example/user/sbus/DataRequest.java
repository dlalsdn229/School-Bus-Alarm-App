package com.example.user.sbus;


import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import java.util.Map;
import java.util.HashMap;


public class DataRequest extends StringRequest {
    final static private  String URL="http://readytoroll.cafe24/SBUSRequest.php";
    private Map<String,String> parameters;

    public DataRequest(String BusDepTime, String TrainDepTime, Response.Listener<String> listener){
        super(Method.POST,URL,listener,null);
        parameters = new HashMap<>();
        parameters.put("BusDepTime", BusDepTime);
        parameters.put("TrainDepTime", TrainDepTime);
    }

    @Override
    public Map<String, String> getParams() {
        return parameters;
    }

}
